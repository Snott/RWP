function f = uplus(f)
%UPLUS   Unary plus for a CHEBFUN2. 

% Copyright 2015 by The University of Oxford and The Chebfun Developers.
% See http://www.chebfun.org/ for Chebfun information. 

% The algorithm below is advocated by Vladimir Rohklin:


end

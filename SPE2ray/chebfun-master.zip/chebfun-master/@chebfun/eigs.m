% EIGS computes selected eigenvalues and eigenfunctions of a linear operator.
% See chebop/eigs.